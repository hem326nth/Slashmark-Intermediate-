I am working as an Intern in Slash mark company.They give different tasks to interns.I completed the task.

(slashmark_test1)=task1

task 1:- To do application( adding tasks,marking as completed,removing tasks,displaying tasks)


(slashmark_test2)=task2

task2:- Number Guessing Game( In this number guessing game, players have 6 chances to guess a randomly selected number between 1 and 200).


(Slashmark_test3)=task 3

task 3:-Random password generator(1t generates Random passwords using random library in python.We can use those passwords as our credential passwors)

(Slashmark_test4)=task 4

task 4:- Ai chatbot(I generates a chatbot using gemini ai with good Tkinter interface)

(Slashmark_test5)=task 5

task 5:-Voice Assistant(It is gui voice assistant,it can change voice)

